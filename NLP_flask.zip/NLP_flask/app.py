import flask
from flask import Flask, render_template, request, url_for
from werkzeug.utils import secure_filename, redirect

from forms import FileInputForm, SelectFileForm, PredictionDataForm

import time


app = Flask(__name__)
app.config['SECRET_KEY'] = "ERTYUIO"
app.config['UPLOAD_FOLDER'] = "/static/File_Upload_Folder"

GET = 'GET'
POST = "POST"


@app.route("/",  methods=[GET])
@app.route("/home",  methods=[GET])
def home():
    return render_template('home.html')

@app.route("/train")
def train():
    input_form  = FileInputForm()
    if input_form.validate_on_submit():
        pass
        ####UPLOAD LOGIC####
        input_form.file.data

    select_form = SelectFileForm()
    if select_form.validate_on_submit():
        pass
        ####DROP DOWN FILE SELCT####

    return render_template("train.html", input_form=input_form, select_form=select_form)

@app.route("/test")
def test():
    form = PredictionDataForm() 
    if form.validate_on_submit():
        pass
        #form.text.data


    return render_template("test.html", form=form)



@app.route('/',methods=['GET','POST'])
def index():
    if request.method == 'POST':
        testing_text = request.form.to_dict().get('test_text')  # Your form's:
        print(testing_text)
    return render_template('index.html')
#@app.route('/Submit', methods=['POST'])
#def submit():

@app.route('/upload_text', methods=['POST'])
def uoload_text():
    data = request.data
    file = open("upload_text/"+str(int(time.time()))+".csv", "wb")
    file.write(data)
    file.close()
    return 'abc'
# do something

@app.route('/training.html')
def training_page():
    return render_template("training.html")



if __name__ == '__main__':
    app.run()
