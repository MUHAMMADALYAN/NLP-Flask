from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms import SubmitField, SelectField, TextAreaField

class FileInputForm(FlaskForm):
	file   = FileField("Upload CSV file", validators=[FileRequired('File was Empty!')])
	submit = SubmitField("Upload")

class SelectFileForm(FlaskForm):
	file_name = SelectField(["A", "B"])
	submit    = SubmitField("Chose")

class PredictionDataForm(FlaskForm):
	text 	 = TextAreaField()
	classify =  SubmitField("Classify")
